package com.assignment;

import java.util.Scanner;
import java.sql.*;
public class JavaExample {
    static Scanner ip=new Scanner(System.in);
    static Scanner sc=new Scanner(System.in);
    private static Connection con ;
    private static Statement stm;
    public static void main(String[] args) throws SQLException {

        try {
            String addr = "jdbc:mysql://localhost:3306/STUDENT";
            String username = "root";
            String password = "root";
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Connected!!!");
            con = DriverManager.getConnection(addr, username, password);
            stm=con.createStatement();
            Scanner ip = new Scanner(System.in);
            while (true) {
                System.out.println("Please CHOOSE your option");
                System.out.println("1.Insert\n2.Delete\n3.Update\n4.Display\n5.Display By ID\n6.Exit");
                int option = ip.nextInt();
                switch (option) {
                    case 1:
                        insert();
                        break;
                    case 2:
                        delete();
                        break;
                    case 3:
                        update();
                        break;
                    case 4:
                        display();
                        break;
                    case 5:
                        displaybyid();
                        break;
                    case 6:
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Choose the CORRECT option");
                }
            }

        } catch (ClassNotFoundException exe) {
        } catch (SQLException exe) {
        }
    }

    public static void insert() throws SQLException {
        System.out.println("STUDENT_NO");
        int STUDENT_NO=ip.nextInt();
        System.out.println("STUDENT_NAME");
        String STUDENT_NAME=sc.nextLine();
        System.out.println("STUDENT_DOB");
        int STUDENT_DOB=ip.nextInt();
        System.out.println("STUDENT_DOJ");
        int STUDENT_DOJ=ip.nextInt();
        String sql1="insert into Student values(?,?,?,?)";
        PreparedStatement pstm=con.prepareStatement(sql1);
        pstm.setInt(1,STUDENT_NO);
        pstm.setString(2,STUDENT_NAME);
        pstm.setInt(3,STUDENT_DOB);
        pstm.setInt(4,STUDENT_DOJ);
        int status= pstm.executeUpdate();
        System.out.println("Insertion Successful");

    }
    public static void delete() throws SQLException {
        System.out.println("Enter STUDENT_No");
        int STUDENT_No=ip.nextInt();
        String sql2="delete from Student where STUDENT_No="+STUDENT_No+"";
        stm.executeUpdate(sql2);
        System.out.println("Deletion Successful");
    }
    public static void update() throws SQLException {
        System.out.println("Enter the STUDENT_NO");
        int STUDENT_NO= ip.nextInt();
        System.out.println("Enter the new STUDENT_NAME");
        String STUDENT_NAME = sc.nextLine();
        String sql3 = "update Student set STUDENT_NAME=? where STUDENT_NO=?";
        PreparedStatement pstm = con.prepareStatement(sql3);
        pstm.setString(1, STUDENT_NAME);
        pstm.setInt(2, STUDENT_NO);
        System.out.println("Update Successful");
        int status = pstm.executeUpdate();
        if (status == 0) {
            System.out.println("Enter the STUDENT_NO which is present in the table");
        }
    }
    public static void display() throws SQLException {
        String sql4 = "select * from student ";
        ResultSet res = stm.executeQuery(sql4);
        while (res.next()) {
            System.out.println("STUDENT_NO :" + res.getInt(1) + "\tSTUDENT_NAME :" + res.getString(2) + "\tSTUDENT_DOB :" + res.getInt(3) + "\tSTUDENT_DOJ :" + res.getInt(4));
        }
    }

    public static void displaybyid() throws SQLException {
        System.out.println("Enter STUDENT_NO");
        int STUDENT_NO=ip.nextInt();
        String sql5 = "select * from student where STUDENT_NO="+STUDENT_NO+"";
        ResultSet res=stm.executeQuery(sql5);
        while (res.next()){
            System.out.println("STUDENT_NO: "+res.getInt(1)+"\tSTUDENT_NAME: "+res.getString(2)+
                    "\tSTUDENT_DOB: "+res.getInt(3)+"\tSTUDENT_DOJ: "+res.getInt(4));
        }
        System.out.println("Display by ID FILTER Successful");
    }

}



